import mongoose, { Schema } from 'mongoose'
import mongooseKeywords from 'mongoose-keywords'
import { env } from '../../config'

var CardSchema = new mongoose.Schema({

  balance: {
    type: Number
  }

});

mongoose.model('Card', CardSchema);

module.exports = mongoose.model('Card');
