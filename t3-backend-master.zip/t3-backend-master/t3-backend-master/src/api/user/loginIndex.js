/*var express = require('express');

var router = express.Router();
*/
import { Router } from 'express'

var bycrypt = require('bcrypt');

var bodyParser = require('body-parser');

var mongoose = require('mongoose');

var User = require('./userModel.js');

router.use(bodyParser.json());

router.use(bodyParser.urlencoded({extended: true}));

router.post('/', function(req, res) {


  var query = {
    email: req.body.email
  };

  User.findOne(query, function(error, user) {

    if (error)
    {
      console.log(error);
    }

    if(!user)
    {
      return res.status(403).send({
        status: "NO_RESULTS"
      });
    }

    user.comparePassword(req.body.password, function (match) {

      if (error)
      {
        console.log(error);
      }

      res.send({
        status: "OK",
        authenticated: match
      }).status(200);

    })

  });


});


module.exports = router;
