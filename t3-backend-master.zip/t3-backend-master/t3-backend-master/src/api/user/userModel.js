import mongoose, { Schema } from 'mongoose'
import mongooseKeywords from 'mongoose-keywords'
import { env } from '../../config'

var UserSchema = new mongoose.Schema({

  name: String,
  first_name: String,
  last_name: String,
  email: String,
  password: String,
  user_type: String,
  card: [{type: mongoose.Schema.ObjectId, ref: 'Card'}]

});

UserSchema.methods.comparePassword = function (password, callback) {


  bcrypt.compare(password, this.password).then(function(res) {
    // res == true

    callback(res);
  });

};

mongoose.model('User', UserSchema);

module.exports = mongoose.model('User');
